﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex2
{
    // This is an AI for the computer player in order to receive the bonus :)
    internal class ComputerPlayer
    {
        static char[,] s_MemoryMatrix;
        static bool s_IsFirstMove = true;
        static bool s_KnowsSecondMove = false;
        static int[] s_IndicesForSecondMove = new int[2];

        public static void InitMemory(int i_Height, int i_Width)
        {
            s_MemoryMatrix = new char[i_Height, i_Width];
        }

        public static void ObserveBoard(int[] i_ObservedChoice)
        {
            s_MemoryMatrix[i_ObservedChoice[0], i_ObservedChoice[1]] = GameManager.GetCellValue(i_ObservedChoice[0], i_ObservedChoice[1]);
        }

        public static int[] MakeChoice()
        {
            int[] choice = new int[2];

            if (s_IsFirstMove)
            {
                int[] matchingIndices = chooseMatchingPair();

                if (areMatchingIndicesFound(matchingIndices))
                {
                    choice[0] = matchingIndices[0];
                    choice[1] = matchingIndices[1];
                    s_IndicesForSecondMove[0] = matchingIndices[2];
                    s_IndicesForSecondMove[1] = matchingIndices[3];
                    s_KnowsSecondMove = true;
                }
                else
                {
                    choice = randomChoice();
                    s_KnowsSecondMove = false;
                }
                s_IsFirstMove = false;
            }
            else
            {
                if(s_KnowsSecondMove)
                {
                    choice = (int[])s_IndicesForSecondMove.Clone(); 
                    
                }
                else
                {
                    choice = randomChoice();
                }
                s_KnowsSecondMove = false;
                s_IsFirstMove = true;
            }

            return choice;
        }

        private static int[] randomChoice()
        {
            int[] randomIndex = new int[2];
            Random indexGenerator= new Random();
            
            do
            {
                randomIndex[0] = indexGenerator.Next(0, s_MemoryMatrix.GetLength(0));
                randomIndex[1] = indexGenerator.Next(0, s_MemoryMatrix.GetLength(1));
            } while (GameManager.IsCellRevealed(randomIndex[0], randomIndex[1]));
            
            return randomIndex;
        }

        private static bool areMatchingIndicesFound(int [] choice)
        {
            return !(choice[2] == -1 && choice[3] == -1);
        }

        private static int[] chooseMatchingPair()
        {
            int[] matchingIndices = new int[4];
            bool foundPair = false;

            for (int i = 0; i < s_MemoryMatrix.GetLength(0); i++) // rows
            {
                for (int j = 0; j < s_MemoryMatrix.GetLength(1); j++) // columns
                {
                    if (s_MemoryMatrix[i, j] != 0 && !GameManager.IsCellRevealed(i, j) && !foundPair)
                    {
                        matchingIndices[0] = i;
                        matchingIndices[1] = j;

                        int [] matchingPair = findPair(s_MemoryMatrix[i, j], i, j);
                        matchingIndices[2] = matchingPair[0];
                        matchingIndices[3] = matchingPair[1];

                        if (matchingPair[0] != -1)
                        {
                            foundPair = true;
                        }
                    }
                }
            }

            return matchingIndices;
        }

        private static int[] findPair(char i_CellValue, int i_RowIndex, int i_ColIndex)
        {
            int[] matchingPairLocation = {-1, -1};
           
            for (int i = 0; i < s_MemoryMatrix.GetLength(0); i++) // rows
            {
                for (int j = 0; j < s_MemoryMatrix.GetLength(1); j++) // columns
                {
                    if (s_MemoryMatrix[i, j] == i_CellValue && !(i_RowIndex == i && i_ColIndex == j))
                    {
                        matchingPairLocation[0] = i;
                        matchingPairLocation[1] = j;
                        break;
                    }
                }
            }

            return matchingPairLocation;
        }
    }
}