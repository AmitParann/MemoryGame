﻿using Ex2;

class Program
{
    static void Main()
    {
        UI.InitializeGame();
    }
}