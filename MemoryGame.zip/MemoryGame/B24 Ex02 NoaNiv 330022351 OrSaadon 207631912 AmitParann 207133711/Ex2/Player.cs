﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex2
{
    class Player
    {
        int m_Score;
        string m_Name;
        bool m_IsComputer;

        public Player(string i_Name, bool i_IsComputer)
        {
            this.m_Score = 0;
            this.m_Name = i_Name;
            this.m_IsComputer = i_IsComputer;
        }

        public string Name
        {
            get { return this.m_Name; }
        }

        public bool IsComputer
        {
            get { return this.m_IsComputer; }
        }

        public int Score
        {
            get { return this.m_Score; }
        }

        public void RaiseScore()
        {
            m_Score++;
        }
    }
}