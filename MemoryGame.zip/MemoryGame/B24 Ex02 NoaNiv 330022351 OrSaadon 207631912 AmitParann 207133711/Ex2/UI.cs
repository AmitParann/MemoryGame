﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Ex2
{
    internal static class UI
    {
        const int k_MinScaleValue = 4;
        const int k_MaxScaleValue = 6;
        
        public static void InitializeGame()
        {
            Console.WriteLine("Write player 1's name");
            String playerOneName = askForName();

            Console.WriteLine("Choose your adversary: type C for computer, H for human");
            String playerTwoName = askForSecondPlayer(out bool isComputerOpponent);
                        
            int[] boardDimensions = askForBoardDimensions();
            GameManager.InitializeGameLogic(playerOneName, playerTwoName, boardDimensions, isComputerOpponent);
            PlayGame();
        }

        private static void PlayGame()
        {

            bool isGameOver = false;

            while (!isGameOver)
            {
                Console.Clear();
                Console.WriteLine(String.Format("It is now {0}'s turn.", GameManager.GetCurrentPlayer().Name));
                int[] playerFirstChoice = askForChoice();
                Console.Clear();
                GameManager.PerformFirstMove(playerFirstChoice);
                int[] playerSecondChoice = askForChoice();
                Console.Clear();
                int turnOutcome = GameManager.PerformSecondMove(playerSecondChoice);
                
                
                
                if (turnOutcome == 0)
                {
                    displayBoard(GameManager.GetBoard());
                    Console.WriteLine(String.Format("{0} failed to find a pair! Not everyone can be smart :)", GameManager.GetPreviousPlayer().Name));
                    Thread.Sleep(2000);
                    GameManager.HideLastTwoChoices();
                }
                else if (turnOutcome == 1)
                {
                    displayBoard(GameManager.GetBoard());
                    Console.WriteLine(String.Format("Good job, {0}! You get a point, and another turn!", GameManager.GetCurrentPlayer().Name));
                    Thread.Sleep(3000);
                }
                else 
                {
                    isGameOver = true;
                    Console.WriteLine(String.Format("Good job, {0}! You get a point, and the game is over!", GameManager.GetCurrentPlayer().Name));
                    Player winner = GameManager.GetWinner();
                    if (winner != null)
                    {
                        Console.WriteLine(String.Format("The winner is: {0}, with {1} points! Congratulations!", winner.Name, winner.Score));
                    }
                    else
                    {
                        Console.WriteLine("There is a tie! Congratulations to both.");
                    }
                    
                    Thread.Sleep(5000);

                    checkIfNextGame();
                }

            }

        }

        private static void checkIfNextGame()
        {
            Console.WriteLine("Press enter for another game, or any other key + enter to quit.");
            string input = Console.ReadLine();

            if(input.Length == 0)
            {
                InitializeGame();
            }
        }

        private static int[] askForChoice()
        {
            int[] choice;
            if(GameManager.GetCurrentPlayer().IsComputer)
            {
                choice = ComputerPlayer.MakeChoice();
            }
            else
            {
                choice = askForChoiceHuman();
            }

            return choice;
        }

        private static int[] askForChoiceHuman()
        {
            displayBoard(GameManager.GetBoard());
            Console.WriteLine("Enter your choice in the format of <CAPITAL LETTER><Digit>");
            string choice = Console.ReadLine();
            if (choice == "Q" || choice == "q")
            {
                Environment.Exit(0);
            }
            int[] parsedChoice;
            while (!tryParseChoice(choice, out parsedChoice))
            {
                choice = Console.ReadLine();
                if (choice == "Q" || choice == "q")
                {
                    Environment.Exit(0);
                }
            }

            return parsedChoice;
        }

        private static bool tryParseChoice(string i_Choice, out int[] o_ParsedChoice)
        {
            bool isValid = true;
            if (i_Choice.Length != 2)
            {
                Console.WriteLine("Invalid choice - 2 characters only");
                isValid = false;
            }
            if (!(char.IsUpper(i_Choice[0]) || char.IsLower(i_Choice[0])))
            {
                Console.WriteLine("Invalid choice - first character must be a letter");
                isValid = false;
            }
            if (!char.IsNumber(i_Choice[1]))
            {
                Console.WriteLine("Invalid choice - second character must be a digit");
                isValid = false;
            }
            o_ParsedChoice = new int[2];

            if (isValid)
            { 
               o_ParsedChoice[1] = char.ToUpper(i_Choice[0]) - 'A';
               o_ParsedChoice[0] = i_Choice[1] - '1';
                if (isValid && !GameManager.IsLogicallyValid(o_ParsedChoice[0], o_ParsedChoice[1]))
                {
                    Console.WriteLine("Choice is out of bounds");
                    isValid = false;
                }
                else if (isValid && GameManager.IsCellRevealed(o_ParsedChoice[0], o_ParsedChoice[1]))
                {
                    Console.WriteLine("Invalid choice - cell is already revealed");
                    isValid = false;
                }
            }

            return isValid;
        }

       private static void displayBoard(gameBoard i_Board)
        {
            char widthIndex = 'A';
            char heightIndex = '1';
            Console.Write("  ");

            for (int i = 0; i < i_Board.Width; i++)
            {
                Console.Write("   " + widthIndex++);
            }

            Console.WriteLine();

            for (int i=0; i < i_Board.Height; i++) 
            {
                
                printLineBreaker(i_Board.Width);

                Console.WriteLine();
                Console.Write(heightIndex++ + "  |");
                for (int j = 0; j < i_Board.Width ; j++)
                {
                    Console.Write(" ");
                    Console.Write(i_Board.IsCellRevealed(i, j) ? i_Board.GetCellValue(i, j) : " ");
                    if (j < i_Board.Width - 1 )
                    {
                        Console.Write(" |");
                    }
                }
               Console.Write(" |");
               Console.WriteLine();
            }
            printLineBreaker(i_Board.Width);
            Console.WriteLine();
        }

       private static void printLineBreaker(int i_Width)
        {
            Console.Write("   =");

            for (int i = 0; i < i_Width; i++)
            {
                Console.Write( "====");
            }

        }

       private static string askForName()
        {
            String name = Console.ReadLine();

            while (name.Length > 20 || name.Length == 0 || name.Any(char.IsWhiteSpace))
            {
                Console.WriteLine("Invalid input. Try again.");
                name = Console.ReadLine();
            }

            return name;
        }

       private static string askForSecondPlayer(out bool o_isComputerOpponent)
        {

            string userChoice = Console.ReadLine();
            string secondPlayerName;

            while (userChoice != "C" && userChoice != "H")
            {
                Console.WriteLine("Invalid input. Enter C or H.");
                userChoice = Console.ReadLine();
            }
            if (userChoice == "C")
            {
                o_isComputerOpponent = true;
                secondPlayerName = "Computer";
            }
            else
            {
                o_isComputerOpponent = false;
                Console.WriteLine("Write player 2's name.");
                secondPlayerName = askForName();
            }
            return secondPlayerName;
        }

       private static int[] askForBoardDimensions()
        {
            int[] boardDimensions = new int[2];

            do
            { 
                Console.WriteLine("Height*Width must be an even number");
                Console.WriteLine(string.Format("Enter the board's height between {0}-{1}", k_MinScaleValue, k_MaxScaleValue));
                boardDimensions[0] = validateMeasurement();
                Console.WriteLine(string.Format("Enter the board's width between {0}-{1}", k_MinScaleValue, k_MaxScaleValue));
                boardDimensions[1] = validateMeasurement();

            } while ((boardDimensions[0] * boardDimensions[1]) %2 == 1);

            return boardDimensions;
        }

        private static int validateMeasurement()
        {
            String userInput = Console.ReadLine();
            int measurement;

            while (!int.TryParse(userInput, out measurement) || measurement < k_MinScaleValue || measurement > k_MaxScaleValue )
            {
                Console.WriteLine("Invalid input, enter a number between " + k_MinScaleValue + "-" + k_MaxScaleValue);
                userInput = Console.ReadLine();
            }

            return measurement;
        }
    }
}