﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Ex2
{
    internal static class GameManager
    {
        static gameBoard s_Board;
        static Player s_PlayerOne;
        static Player s_PlayerTwo;
        
        static bool s_IsPlayerOneTurn = true;
        static int[] s_CurrentTurnFirstChoice = new int[2];
        static int[] s_CurrentTurnSecondChoice = new int[2];
        public static gameBoard GetBoard()
        {
            return s_Board; 
        }

        public static Player GetWinner()
        {
            Player winner;

            if(s_PlayerOne.Score > s_PlayerTwo.Score)
            {
                winner = s_PlayerOne;
            }
            else if(s_PlayerOne.Score < s_PlayerTwo.Score)
            {
                winner = s_PlayerTwo;
            }
            else
            {
                winner = null;
            }

            return winner;
        }

        public static bool IsGameOver()
        {
            return s_Board.isRevealed();
        }

        public static Player GetCurrentPlayer()
        {
            Player currentPlayer;
           
            if(s_IsPlayerOneTurn)
            {
                currentPlayer = s_PlayerOne;
            }
            else
            {
                currentPlayer = s_PlayerTwo;
            }

            return currentPlayer;
        }

        public static Player GetPreviousPlayer()
        {
            Player previousPlayer;
          
            if (s_IsPlayerOneTurn)
            {
                previousPlayer = s_PlayerTwo;
            }
            else
            {
                previousPlayer = s_PlayerOne;
            }

            return previousPlayer;
        }

        public static void PerformFirstMove(int[] i_PlayerChoice)
        {
            s_CurrentTurnFirstChoice[0] = i_PlayerChoice[0];
            s_CurrentTurnFirstChoice[1] = i_PlayerChoice[1];
            RevealCell(i_PlayerChoice[0], i_PlayerChoice[1]);
           
            if (GetPreviousPlayer().IsComputer || GetCurrentPlayer().IsComputer)
            {
                ComputerPlayer.ObserveBoard(i_PlayerChoice);
            }
        }

        public static int PerformSecondMove(int[] i_PlayerChoice) 
        {
            s_CurrentTurnSecondChoice[0] = i_PlayerChoice[0];
            s_CurrentTurnSecondChoice[1] = i_PlayerChoice[1];
            int turnOutcome; // 0 = no matching pair, 1 = found matching pair, 2 = found matching pair, and game is over

            RevealCell(i_PlayerChoice[0], i_PlayerChoice[1]);
            bool isMatchingChoice = s_Board.GetCellValue(s_CurrentTurnFirstChoice[0], s_CurrentTurnFirstChoice[1]) == s_Board.GetCellValue(s_CurrentTurnSecondChoice[0], s_CurrentTurnSecondChoice[1]);
            if (isMatchingChoice)
            {
                if(s_IsPlayerOneTurn)
                {
                    s_PlayerOne.RaiseScore();
                    s_IsPlayerOneTurn = true;
                }
                else
                {
                    s_PlayerTwo.RaiseScore();
                    s_IsPlayerOneTurn = false;
                }

                if (IsGameOver())
                {
                    turnOutcome = 2;
                }
                else
                {
                    turnOutcome = 1;
                }
            }
            else
            {
                s_IsPlayerOneTurn = !s_IsPlayerOneTurn;
                turnOutcome = 0;
            }

            if(GetPreviousPlayer().IsComputer || GetCurrentPlayer().IsComputer)
            {
                ComputerPlayer.ObserveBoard(i_PlayerChoice);
            }

            return turnOutcome;
        }
        public static void HideLastTwoChoices()
        {
            s_Board.HideCell(s_CurrentTurnFirstChoice[0], s_CurrentTurnFirstChoice[1]);
            s_Board.HideCell(s_CurrentTurnSecondChoice[0], s_CurrentTurnSecondChoice[1]);
        }
        
        public static char GetCellValue(int i, int j)
        {
            return s_Board.GetCellValue(i, j);
        }

        public static void InitializeGameLogic(string i_PlayerOneName, string i_PlayerTwoName, int[] i_BoardDimensions, bool isComputerOpponent)
        {
            s_PlayerOne = new Player(i_PlayerOneName, false);
            s_PlayerTwo = new Player(i_PlayerTwoName, isComputerOpponent);
            s_IsPlayerOneTurn = true;
            int boardHeight = i_BoardDimensions[0];
            int boardWidth = i_BoardDimensions[1];
            s_Board = new gameBoard(boardHeight, boardWidth);
          
            if (isComputerOpponent)
            {
                ComputerPlayer.InitMemory(boardHeight, boardWidth);
            }
        }

        public static bool IsLogicallyValid(int i_FirstIndex, int i_SecondIndex)
        {
            return i_FirstIndex < s_Board.Height && i_SecondIndex < s_Board.Width;
        }

        public static bool IsCellRevealed(int i, int j)
        {
            return s_Board.IsCellRevealed(i, j);
        }

        public static void RevealCell(int i, int j)
        {
            s_Board.RevealCell(i, j);
        }
    }

    class gameBoard
    {
        readonly int m_Height;
        readonly int m_Width;
        private char[,] m_ValueArray;
        private bool[,] m_RevealedArray;

        public gameBoard(int i_Height, int i_Width)
        {
            this.m_Height = i_Height;
            this.m_Width = i_Width;
            this.m_ValueArray = new char[i_Height, i_Width];
            this.m_RevealedArray = new bool[i_Height, i_Width];
            initValueArray(i_Height, i_Width);
        }

        public int Height
        {
            get { return m_Height; }
        }

        public int Width
        {
            get { return m_Width; }
        }

        public char GetCellValue(int i, int j)
        {
            return m_ValueArray[i, j];
        }

        public bool IsCellRevealed(int i, int j)
        {
            return m_RevealedArray[i, j];
        }

        public bool isRevealed()
        {
            bool isRevealed = true;

            foreach (bool value in this.m_RevealedArray)
            {
                if (!value)
                {
                    isRevealed = false;
                    break;
                }
            }

            return isRevealed;
        }

        private void initValueArray(int i_Height, int i_Width)
        {
            Random charGenerator = new Random();
            int slotNumber = i_Height * i_Width;
            bool[] used_Chars = new bool[slotNumber/ 2];
            for (int i = 0; i < slotNumber / 2; i++)
            {
                int randomNum = charGenerator.Next(0, slotNumber/2);

                while (used_Chars[randomNum] == true)
                {
                    
                    randomNum = charGenerator.Next(0, slotNumber/2);
                }
                used_Chars[randomNum] = true;
                randomlyPlugInChar((char)(randomNum + 'A'));
                randomlyPlugInChar((char)(randomNum + 'A'));
            }
        }

        private void randomlyPlugInChar(char i_char)
        {
            Random index_Generator = new Random();
            int index_Row = index_Generator.Next(0, this.m_Height);
            int index_Column = index_Generator.Next(0, this.m_Width);

            while (this.m_ValueArray[index_Row, index_Column] != 0)
            {
                index_Row = index_Generator.Next(0, this.m_Height);
                index_Column = index_Generator.Next(0, this.m_Width);
            }
            m_ValueArray[index_Row, index_Column] = i_char;
        }

        public void RevealCell(int i, int j)
        {
            this.m_RevealedArray[i,j] = true;
        }

        public void HideCell(int i, int j)
        {
            this.m_RevealedArray[i, j] = false;
        }
    }
}